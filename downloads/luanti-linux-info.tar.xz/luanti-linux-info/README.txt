Luanti para Linux
=================

Não há um único instalador oficial direto para Linux no GitHub.
Use uma destas opcoes:

1) Flatpak (recomendado):
   flatpak install flathub net.luanti.luanti

2) AppImage / Snap / pacotes da distro:
   Acesse https://www.luanti.org/download/

3) Compile a partir do codigo-fonte:
   https://github.com/luanti-org/luanti

Versao: 5.17.0
