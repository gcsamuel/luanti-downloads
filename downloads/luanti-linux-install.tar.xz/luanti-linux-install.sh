#!/bin/bash
# Script de instalação do Luanti para Linux
# Versão 5.17.0

echo "=== Instalador do Luanti para Linux ==="
echo ""
echo "O Luanti não possui um único instalador oficial direto para Linux."
echo "Escolha uma das opções abaixo:"
echo ""
echo "1) Flatpak (Recomendado)"
echo "   flatpak install flathub net.luanti.luanti"
echo ""
echo "2) AppImage / .deb / Pacotes da distro"
echo "   Acesse: https://www.luanti.org/download/"
echo ""
echo "3) Código-fonte (compilar)"
echo "   Acesse: https://github.com/luanti-org/luanti"
echo ""
echo "Após a instalação, execute: luanti"
echo ""
echo "=== Fim ==="
